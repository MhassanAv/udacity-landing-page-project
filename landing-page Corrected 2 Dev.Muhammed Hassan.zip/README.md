# Landing Page Project <h1>

### Table of Contents<h3>
1._Global variables_
2._Building the nav bar_
3._Scroll to anchor_
4._Adding go top top button_
5._Adding add content button_
6._Adding active class
### Instractions <h3>
**i did try to remove the _href_ attribute but it didn't work as intended.**
first i established some variables , and then i start to work on the main requirements.
it's pretty straight forword, nothing is complex or hard to understand, Enjoy !
### Usage <h3>
this is for educational purposes only .
### Technologies Used <h3>
1._Observer API_
2._scrollIntoView_
3._forEach_
4._For..of_
5._fragments_

### **Final Verdict** <h3>
i think i have learned alot from this project though it's kinda hard and tricky.
i have learned a new tricks also like (observer api,scrollIntoView, etc...).
it was kinda fun and i felt so good when it worked.
i'm not 100% sure if my syntax matches the style guide but i tried .
thank you for this nice/tough experience. 
**Dev.Muhammed Hassan**

### Fixes <h3>
1._the highlight functionality in navbar was missing and i fixed it._
2._the highlight functionality did not work on mobile because of_**observer's threshold**_and it's fixed now._
